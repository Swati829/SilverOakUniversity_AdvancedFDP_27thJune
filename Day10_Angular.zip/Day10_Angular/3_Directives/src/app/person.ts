export interface Person {
    id: number;
    name: string;
    gender?: string;
  }
  
  export const Persons: Person[] = [
    { id: 1, name: 'Nandini', gender: 'Female'},
    { id: 2, name: 'Pooja', gender: 'Female' },
    { id: 3, name: 'Dhruv', gender: 'Male' },
    { id: 4, name: 'Hiren',gender: 'Male'}
  ];
  