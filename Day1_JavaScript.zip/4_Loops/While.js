let i=0;
while (i < 15) {
    document.write("<br/>"+i);
    i++;
  }