const cities = ["London", "Paris", "Chicago"];
for (C of cities) {
  document.write("<br/>"+C);
}