let x=20,y=50;
var z=x+y;
console.log("Sum of x+y is:",z);
document.write("Sum of x+y is:",z);
