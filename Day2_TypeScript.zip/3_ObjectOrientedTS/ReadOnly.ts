class Person {
    readonly birthDate: Date;

    constructor(birthDate: Date) {
        this.birthDate = birthDate;
    }
}

let person = new Person(new Date(1988, 08, 22));
console.log("Person Date: "+person.birthDate);
// person.birthDate = new Date(1991, 12, 25); // Compile error