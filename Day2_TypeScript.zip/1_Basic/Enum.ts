// Enums
var Month;
(function (Month) {
    Month[Month["Jan"] = 0] = "January";
    Month[Month["Feb"] = 1] = "Februay";
    Month[Month["Mar"] = 2] = "March";
    Month[Month["Apr"] = 3] = "April";
    Month[Month["May"] = 4] = "May";
    Month[Month["Jun"] = 5] = "June";
    Month[Month["Jul"] = 6] = "July";
    Month[Month["Aug"] = 7] = "August";
    Month[Month["Sep"] = 8] = "September";
    Month[Month["Oct"] = 9] = "October";
    Month[Month["Nov"] = 10] = "November";
    Month[Month["Dec"] = 11] = "December";
})(Month || (Month = {}));
;


function isItSummer(month) {
    var isSummer;
    switch (month) {
        case Month.Jun:
        case Month.Jul:
        case Month.Aug:
            isSummer = true;
            break;
        default:
            isSummer = false;
            break;
    }
    return isSummer;
}
console.log(isItSummer(Month.Nov));
