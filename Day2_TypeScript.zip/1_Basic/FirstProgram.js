var mes = "Hello Swati!!";
console.log(mes);
