var msg;
msg = "Hello!! Typescript";
console.log(msg);
var input;
input = 1;
input = "God Is Great.";
console.log(input);
