var fname:string = "Swati"; 
var lname:string = "Solanki"; 
var fullname=fname+" "+lname;

var numInt:number = 50;
var numFloat:number = 42.50
var sum = numInt + numFloat;

console.log("Firstname: "+fname); 
console.log("Lastname: "+lname); 
console.log("Fullname: "+fullname); 

console.log("Integer Number: "+numInt); 
console.log("Float Number: "+numFloat);
console.log("Sum: "+sum);