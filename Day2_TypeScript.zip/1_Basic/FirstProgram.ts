var mes:string = "Hello Swati!!"
console.log(mes);
