//Alias DataType
type chars=string;
let msg:chars;
msg="Hello!! Typescript";
console.log(msg);

//Union Datatype
type alphanumeric = string | number;
let input: alphanumeric;
input = 1; 
input = "God Is Great."; 
console.log(input);