function addNumber(w: number, y: number): number {
    return w + y;

}
console.log(addNumber(20, 30));

let a = function (n1: number, n2: number, n3: number): number {
    return n1 + n2 + n3;
}
console.log(a(10, 20, 30));

let abc: (s1: string, s2: string) => string =function(r1:string,r2:string)
{
    return(r1+r2);
}
console.log(abc("avc","gbv"));


let f1: (q1: number, q2: number)=> number = function(p1: number, p2: number)
{
    return (p1+p2);
}
console.log(f1(10,60));




/*
function addNum(a: number, b: number): number {
    return a + b;
}

function showMes(mes: string): void {
    console.log(mes.toUpperCase());
}
let addNum2:(x: number, y: number)=>number;

let addNum3 = function (x: number, y: number) {
    return x + y;
};

let addNum4: (a: number, b: number) => number =
    function (x: number, y: number) {
        return x + y;
};

console.log(addNum(11,22));
console.log(showMes("God is great."));
//console.log(addNum2);
console.log(addNum3(11,22));
console.log(addNum4(11,22));

*/
