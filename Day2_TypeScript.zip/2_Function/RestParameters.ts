// A rest parameter allows you a function to accept zero or more arguments of the specified type.

function sum(...string: string[]): string {
    let total = " ";
    string.forEach((str) => total += str);
    return total;
}

console.log("No Arguments: "+sum()); // No arguments.
console.log("2 Arguments: "+sum("a","b")); // 2 arguments.
console.log("3 Arguments: "+sum("3", "20", "10")); // 3 arguments.



