function addNumber(w, y) {
    return w + y;
}
console.log(addNumber(20, 30));
var a = function (n1, n2, n3) {
    return n1 + n2 + n3;
};
console.log(a(10, 20, 30));
var abc = function (r1, r2) {
    return (r1 + r2);
};
console.log(abc("avc", "gbv"));
var f1 = function (p1, p2) {
    return (p1 + p2);
};
console.log(f1(10, 60));
/*
function addNum(a: number, b: number): number {
    return a + b;
}

function showMes(mes: string): void {
    console.log(mes.toUpperCase());
}
let addNum2:(x: number, y: number)=>number;

let addNum3 = function (x: number, y: number) {
    return x + y;
};

let addNum4: (a: number, b: number) => number =
    function (x: number, y: number) {
        return x + y;
};

console.log(addNum(11,22));
console.log(showMes("God is great."));
//console.log(addNum2);
console.log(addNum3(11,22));
console.log(addNum4(11,22));

*/
