import React from 'react';

class ClassComponent extends React.Component{
    render()
    {
        return <h2>Custom Class components </h2> 
    }
}
export default ClassComponent;
