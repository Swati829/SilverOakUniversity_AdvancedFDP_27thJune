

function FunctionComponent (){
    return(<h2> MyFunction Component</h2>);  
}
export default FunctionComponent;
