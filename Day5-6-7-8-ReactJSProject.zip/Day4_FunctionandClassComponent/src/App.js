
import React from 'react';
import './App.css';
import ClassComponent from './components/class';
import FunctionComponent from './components/function';

function App() {
  return (
    //<div className="App">
    //<React.Fragment>
    <>
      <ClassComponent/>
      <FunctionComponent/>
    </>
     
      //</React.Fragment>
    //</div>
  );
}

export default App;
