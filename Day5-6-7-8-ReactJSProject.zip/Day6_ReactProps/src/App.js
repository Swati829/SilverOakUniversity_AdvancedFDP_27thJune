import './App.css';

import PersonDefaultDemo from './Components/DefaultProp'

import ArrayProps from './Components/ArrayAsProps'


// import ParentSampleRenderProps from './Components/RenderPropDemo'

import GrandParent from './Components/DefaultProp';

function App() {
  return (
    // Default Prop - Class Componet with Props
    <div >
       <PersonDefaultDemo></PersonDefaultDemo>
       <PersonDefaultDemo name="Swati Solanki" gender="Female" designation="Founder"></PersonDefaultDemo>
       <PersonDefaultDemo name="Ankita Solanki" gender="Female" designation="Co-Founder"></PersonDefaultDemo>
       <PersonDefaultDemo name="Aniket Solanki" gender="Male" designation="Chairman"></PersonDefaultDemo>
    </div>

    // Array as Props
    // <ArrayProps></ArrayProps>


    // Render Props
    // <ParentSampleRenderProps/>
    
  );
}

export default App;
