import {useState , useEffect} from "react";
  
// Remember to start the name of your custom hook with "use"
function useCustomReactHook(init , componentName){
    const [counter , setCounter] = useState(init);
      
    // Increases the value of counter by 1
    function resetCounter(){
        setCounter(counter + 1);
    }
      
  
    useEffect(() => {
        // Some logic that will be used in multiple components
        alert("The button of the " + componentName + " is clicked "+ counter + " times.");
    } , [counter , componentName]); 
      
    // Calls the useEffect hook if the counter updates
    return resetCounter;
}
  
export default useCustomReactHook;